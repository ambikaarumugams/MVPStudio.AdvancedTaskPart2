/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 63.9301941346551, "KoPercent": 36.0698058653449};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4249277158199091, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.32813150228880567, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [0.8878485226799834, 500, 1500, "SignOut"], "isController": false}, {"data": [0.2767374115688722, 500, 1500, "UpdateSkill"], "isController": false}, {"data": [0.28818143986683314, 500, 1500, "UpdateEducation"], "isController": false}, {"data": [0.33146067415730335, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [0.8168955472326259, 500, 1500, "DescriptionEdit"], "isController": false}, {"data": [0.13025384935497294, 500, 1500, "ManageListingsView"], "isController": false}, {"data": [0.342488555971702, 500, 1500, "ManageListingsEnable/Disable"], "isController": false}, {"data": [0.3297960882230545, 500, 1500, "AddCertification"], "isController": false}, {"data": [0.23631535947712418, 500, 1500, "AddLanguage"], "isController": false}, {"data": [0.32251352476071576, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.20781893004115226, 500, 1500, "UpdateLanguage"], "isController": false}, {"data": [0.2894298793175198, 500, 1500, "UpdateCertification"], "isController": false}, {"data": [0.004624491305956345, 500, 1500, "SignIn"], "isController": false}, {"data": [0.8814865794907089, 500, 1500, "GetLanguage"], "isController": false}, {"data": [0.235147486497715, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [0.3241781106949646, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [0.20245526425301708, 500, 1500, "SearchSkillsByCategories"], "isController": false}, {"data": [0.3293799417394923, 500, 1500, "AddEducation"], "isController": false}, {"data": [0.35726175613816064, 500, 1500, "ManageListingsDelete"], "isController": false}, {"data": [0.36100707449022057, 500, 1500, "ShareSkillAddNew"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 58104, 20958, 36.0698058653449, 8781.540513561991, 0, 450839, 68.0, 3754.800000000003, 53310.10000000004, 314535.3200000016, 31.751166679417263, 21.25752665756593, 18.916428347236035], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 2403, 1558, 64.83562213899293, 267.1548064918847, 3, 2435, 62.0, 840.1999999999998, 1196.799999999997, 1707.7600000000002, 1.3523103234233318, 0.28545190301239365, 0.7176943736813849], "isController": false}, {"data": ["SignOut", 2403, 108, 4.49438202247191, 227.38660008322907, 3, 4974, 28.0, 368.0, 1495.799999999997, 4006.96, 1.3516736453451352, 0.2686036310901251, 0.652314236630637], "isController": false}, {"data": ["UpdateSkill", 2403, 1682, 69.99583853516438, 281.14024136496016, 3, 2501, 76.0, 895.0, 1253.3999999999978, 1869.7600000000002, 1.3527381548156183, 0.3209176487223858, 0.8248096867563951], "isController": false}, {"data": ["UpdateEducation", 2403, 1649, 68.62255513940907, 325.42571785268456, 3, 2719, 109.0, 992.1999999999998, 1359.0, 1858.8000000000002, 1.3521452011505894, 0.19881821549328824, 0.9486862425978069], "isController": false}, {"data": ["DeleteCertification", 2403, 1558, 64.83562213899293, 292.37994173949284, 3, 2783, 80.0, 935.5999999999999, 1276.3999999999992, 1692.3600000000006, 1.3521687875778283, 0.20057023079855613, 0.7162987808394926], "isController": false}, {"data": ["DescriptionEdit", 2403, 108, 4.49438202247191, 347.9741989180195, 3, 2851, 109.0, 1076.9999999999995, 1461.7999999999997, 2113.3200000000006, 1.3520257599448162, 0.28632041308522377, 1.2387140855849748], "isController": false}, {"data": ["ManageListingsView", 2403, 108, 4.49438202247191, 9640.424885559743, 4, 105221, 5117.0, 25239.6, 31294.399999999983, 91474.32, 1.3504514149392635, 7.153228866355608, 0.7348088045933894], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2403, 108, 4.49438202247191, 5214.836454431961, 6, 85089, 2219.0, 9588.8, 13293.4, 73404.20000000001, 1.3505690599971898, 0.24772661409301672, 0.7062864444288324], "isController": false}, {"data": ["AddCertification", 2403, 1558, 64.83562213899293, 275.01498127340756, 3, 3026, 69.0, 851.0, 1222.7999999999997, 1758.96, 1.3523575086231785, 0.28274414699473294, 0.8467815268344198], "isController": false}, {"data": ["AddLanguage", 2448, 1841, 75.20424836601308, 166.77573529411723, 6, 2441, 52.0, 439.1999999999998, 776.049999999997, 1559.079999999998, 1.3620961145763202, 0.30495877249294745, 0.7534055011044775], "isController": false}, {"data": ["AddSkill", 2403, 1572, 65.41822721598002, 248.62089055347448, 3, 2587, 49.0, 811.0, 1208.9999999999986, 1828.88, 1.3528561986486074, 0.2934351929874983, 0.7916055401305115], "isController": false}, {"data": ["Debug Sampler", 2403, 0, 0.0, 0.41531419059509084, 0, 38, 0.0, 1.0, 1.0, 2.9600000000000364, 1.3508575668823466, 1.5487283096150928, 0.0], "isController": false}, {"data": ["UpdateLanguage", 2430, 1885, 77.57201646090535, 225.55802469135773, 4, 2760, 74.0, 610.9000000000001, 1075.4499999999962, 1677.3500000000008, 1.351726455066777, 0.2855638387237366, 0.7911135093516664], "isController": false}, {"data": ["UpdateCertification", 2403, 1642, 68.33125260091552, 315.203495630462, 3, 6406, 104.0, 937.0, 1288.799999999997, 1707.2400000000007, 1.3521543312828754, 0.18075729170886873, 0.8800285613061034], "isController": false}, {"data": ["SignIn", 2703, 108, 3.995560488346282, 149314.9419163888, 247, 450839, 121291.0, 287300.0, 363039.3999999998, 415155.8, 1.4770653231182855, 0.6877252415326943, 0.797999030385578], "isController": false}, {"data": ["GetLanguage", 7265, 324, 4.459738472126634, 212.68492773571816, 2, 2413, 48.0, 674.0, 1048.6999999999998, 1573.0, 4.039095553937075, 1.0706712068848092, 1.9180611142538653], "isController": false}, {"data": ["DeleteLanguage", 2407, 1803, 74.90652264229331, 258.7885334441215, 5, 2521, 70.0, 831.2000000000003, 1063.0, 1623.6800000000003, 1.3415449782632929, 0.18031898356509865, 0.7074074622394382], "isController": false}, {"data": ["DeleteSkill", 2403, 1572, 65.41822721598002, 259.99500624219667, 2, 2462, 48.0, 871.1999999999998, 1209.1999999999975, 1741.6400000000003, 1.3525280116262248, 0.3136936592650983, 0.8246815554269131], "isController": false}, {"data": ["SearchSkillsByCategories", 2403, 0, 0.0, 8485.199750312113, 70, 98371, 3762.0, 27215.799999999996, 31357.99999999999, 36020.560000000005, 1.351051239306989, 6.885875408147632, 0.9224879901285551], "isController": false}, {"data": ["AddEducation", 2403, 1558, 64.83562213899293, 283.74656679151013, 3, 2487, 65.0, 917.0, 1302.7999999999997, 1824.6000000000004, 1.3523042352502888, 0.2827330088642614, 0.8691985328793387], "isController": false}, {"data": ["ManageListingsDelete", 2403, 108, 4.49438202247191, 4205.809821057015, 5, 78295, 1916.0, 7973.599999999996, 13901.399999999925, 68696.00000000001, 1.351018576927099, 0.2609059751790395, 0.714437645896513], "isController": false}, {"data": ["Transaction Controller", 0, 0, NaN, NaN, 9223372036854775807, -9223372036854775808, NaN, NaN, NaN, NaN, 0.0, 0.0, 0.0], "isController": true}, {"data": ["ShareSkillAddNew", 2403, 108, 4.49438202247191, 12408.71743653765, 4, 91644, 1699.0, 56686.99999999996, 71921.79999999997, 77204.36, 1.3516835294296323, 0.2912906482399708, 2.0475626498354975], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 12536, 59.81486783089989, 21.57510670521823], "isController": false}, {"data": ["500/Internal Server Error", 6154, 29.36348888252696, 10.591353435219606], "isController": false}, {"data": ["401/Unauthorized", 2268, 10.821643286573146, 3.903345724907063], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 58104, 20958, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 12536, "500/Internal Server Error", 6154, "401/Unauthorized", 2268, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["DeleteEducation", 2403, 1558, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1450, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["SignOut", 2403, 108, "401/Unauthorized", 108, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateSkill", 2403, 1682, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1574, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateEducation", 2403, 1649, "500/Internal Server Error", 1450, "401/Unauthorized", 108, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 91, "", "", "", ""], "isController": false}, {"data": ["DeleteCertification", 2403, 1558, "500/Internal Server Error", 1450, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["DescriptionEdit", 2403, 108, "401/Unauthorized", 108, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsView", 2403, 108, "401/Unauthorized", 108, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2403, 108, "401/Unauthorized", 108, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddCertification", 2403, 1558, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1450, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["AddLanguage", 2448, 1841, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1733, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["AddSkill", 2403, 1572, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1464, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateLanguage", 2430, 1885, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1777, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateCertification", 2403, 1642, "500/Internal Server Error", 1451, "401/Unauthorized", 108, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 83, "", "", "", ""], "isController": false}, {"data": ["SignIn", 2703, 108, "500/Internal Server Error", 108, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetLanguage", 7265, 324, "401/Unauthorized", 324, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteLanguage", 2407, 1803, "500/Internal Server Error", 1695, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteSkill", 2403, 1572, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1464, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["AddEducation", 2403, 1558, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1450, "401/Unauthorized", 108, "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsDelete", 2403, 108, "401/Unauthorized", 108, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["ShareSkillAddNew", 2403, 108, "401/Unauthorized", 108, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
