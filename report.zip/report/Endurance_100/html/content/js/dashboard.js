/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 72.95036359101287, "KoPercent": 27.049636408987126};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.5675185632878604, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5027688047992617, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [0.997229916897507, 500, 1500, "SignOut"], "isController": false}, {"data": [0.4368372521899493, 500, 1500, "UpdateSkill"], "isController": false}, {"data": [0.4561808118081181, 500, 1500, "UpdateEducation"], "isController": false}, {"data": [0.5036934441366574, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [0.9729916897506925, 500, 1500, "DescriptionEdit"], "isController": false}, {"data": [0.17751615881809787, 500, 1500, "ManageListingsView"], "isController": false}, {"data": [0.5877192982456141, 500, 1500, "ManageListingsEnable/Disable"], "isController": false}, {"data": [0.5066943674976916, 500, 1500, "AddCertification"], "isController": false}, {"data": [0.37995391705069126, 500, 1500, "AddLanguage"], "isController": false}, {"data": [0.48686030428769017, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.3453917050691244, 500, 1500, "UpdateLanguage"], "isController": false}, {"data": [0.45267774699907665, 500, 1500, "UpdateCertification"], "isController": false}, {"data": [0.00264783759929391, 500, 1500, "SignIn"], "isController": false}, {"data": [0.9943155630665232, 500, 1500, "GetLanguage"], "isController": false}, {"data": [0.3805901337021669, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [0.4863929889298893, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [0.2790858725761773, 500, 1500, "SearchSkillsByCategories"], "isController": false}, {"data": [0.5041512915129152, 500, 1500, "AddEducation"], "isController": false}, {"data": [0.6059556786703602, 500, 1500, "ManageListingsDelete"], "isController": false}, {"data": [0.5976454293628809, 500, 1500, "ShareSkillAddNew"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 52119, 14098, 27.049636408987126, 3018.604136687212, 0, 164653, 56.0, 1431.7000000000044, 4208.400000000009, 108143.28000000364, 28.552770773059734, 19.69063341958587, 17.37761253261006], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 2167, 1070, 49.37701892016613, 85.9953853253348, 3, 1210, 43.0, 211.20000000000005, 316.1999999999998, 577.5600000000013, 1.2365757067369694, 0.26444792237306125, 0.6733462021447484], "isController": false}, {"data": ["SignOut", 2166, 0, 0.0, 52.61634349030467, 4, 773, 30.0, 116.0, 169.0, 374.5199999999968, 1.2518581366155213, 0.2525531949402044, 0.618593962038529], "isController": false}, {"data": ["UpdateSkill", 2169, 1200, 55.325034578146614, 127.81881051175678, 6, 1604, 76.0, 290.0, 435.0, 749.6000000000022, 1.2364631794490584, 0.2890784706264462, 0.7707736743293371], "isController": false}, {"data": ["UpdateEducation", 2168, 1158, 53.413284132841326, 134.03828413284074, 7, 1665, 78.0, 322.10000000000014, 455.5499999999997, 697.2399999999998, 1.2369663514342362, 0.19979170232644386, 0.8849586614032836], "isController": false}, {"data": ["DeleteCertification", 2166, 1065, 49.16897506925208, 115.61172668513356, 6, 2082, 56.0, 268.0, 415.0, 856.6099999999988, 1.2428290599369518, 0.20343319693389594, 0.6755754835399742], "isController": false}, {"data": ["DescriptionEdit", 2166, 0, 0.0, 159.1315789473684, 10, 2498, 91.5, 364.5999999999999, 506.0, 1120.9899999999998, 1.2428689960992505, 0.26702263588069836, 1.1530522913030157], "isController": false}, {"data": ["ManageListingsView", 2166, 0, 0.0, 3736.39889196677, 204, 31595, 2332.5, 8560.0, 12500.850000000008, 21686.449999999997, 1.2427242397207026, 6.881960090357126, 0.6905371996104295], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2166, 0, 0.0, 1458.1265004616791, 9, 22989, 489.5, 3913.1999999999994, 5364.650000000014, 11785.369999999979, 1.2439160959641642, 0.23038243797648275, 0.6656894732308222], "isController": false}, {"data": ["AddCertification", 2166, 1065, 49.16897506925208, 93.97276084949222, 5, 1128, 49.0, 232.0, 357.3000000000002, 612.9899999999998, 1.2425125140399325, 0.26071775497894156, 0.7923444059258554], "isController": false}, {"data": ["AddLanguage", 2170, 1340, 61.75115207373272, 99.06543778801847, 7, 1056, 50.0, 245.9000000000001, 368.4499999999998, 713.0299999999997, 1.2300360054779114, 0.2746114280122845, 0.6942976671545243], "isController": false}, {"data": ["AddSkill", 2169, 1109, 51.12955278930383, 82.61595205163658, 4, 1465, 46.0, 203.0, 281.0, 466.5000000000009, 1.2366027574702152, 0.26788338391298966, 0.7378557468889663], "isController": false}, {"data": ["Debug Sampler", 2166, 0, 0.0, 0.5503231763619592, 0, 61, 0.0, 1.0, 1.0, 3.0, 1.2440839957726417, 1.4632255316865208, 0.0], "isController": false}, {"data": ["UpdateLanguage", 2170, 1409, 64.93087557603687, 107.76267281106001, 6, 1740, 64.0, 253.0, 353.7999999999993, 579.1599999999999, 1.2299056373320003, 0.2629717008702291, 0.736405778955351], "isController": false}, {"data": ["UpdateCertification", 2166, 1163, 53.69344413665743, 141.8384118190211, 7, 1832, 81.0, 344.0, 464.60000000000036, 764.6299999999992, 1.2425845069331742, 0.17680570052852868, 0.8259117673570296], "isController": false}, {"data": ["SignIn", 2266, 0, 0.0, 57628.42806707845, 771, 164653, 43216.0, 123212.9, 137001.55000000005, 154253.65999999995, 1.2414009971747992, 0.5964543853613293, 0.7055041150854326], "isController": false}, {"data": ["GetLanguage", 6509, 0, 0.0, 78.00430173605766, 4, 1591, 41.0, 189.0, 269.5, 527.0, 3.686901671482277, 1.1028866483421405, 1.7930439769513418], "isController": false}, {"data": ["DeleteLanguage", 2169, 1340, 61.77962194559705, 102.5504840940527, 6, 1509, 55.0, 257.0, 360.5, 571.5000000000009, 1.236380011571468, 0.1798617578299792, 0.6685785967386131], "isController": false}, {"data": ["DeleteSkill", 2168, 1109, 51.15313653136531, 78.11992619926194, 4, 911, 40.0, 185.10000000000014, 282.0, 571.7199999999993, 1.2369910534964397, 0.28307407860427697, 0.7710984616421512], "isController": false}, {"data": ["SearchSkillsByCategories", 2166, 0, 0.0, 2833.7405355493875, 138, 37570, 1858.5, 6101.7, 10689.900000000001, 16454.409999999996, 1.2476850718455774, 6.3599585248039325, 0.8663125840646537], "isController": false}, {"data": ["AddEducation", 2168, 1070, 49.35424354243543, 84.03505535055349, 4, 880, 47.0, 194.0, 287.0, 549.9299999999998, 1.236905659128655, 0.25957706869333586, 0.8093035074376941], "isController": false}, {"data": ["ManageListingsDelete", 2166, 0, 0.0, 1287.3176361957512, 13, 37608, 399.0, 3344.699999999999, 4541.950000000001, 7839.899999999998, 1.247185052665642, 0.24359083059875822, 0.6747466007585603], "isController": false}, {"data": ["Transaction Controller", 0, 0, NaN, NaN, 9223372036854775807, -9223372036854775808, NaN, NaN, NaN, NaN, 0.0, 0.0, 0.0], "isController": true}, {"data": ["ShareSkillAddNew", 2166, 0, 0.0, 1328.7746999076637, 18, 14505, 516.5, 3541.5, 5349.25, 9183.569999999976, 1.2432520857189595, 0.2719613937510224, 1.8976591894323573], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 9558, 67.79685061710882, 18.338801588672077], "isController": false}, {"data": ["500/Internal Server Error", 4540, 32.20314938289119, 8.710834820315048], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 52119, 14098, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 9558, "500/Internal Server Error", 4540, "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["DeleteEducation", 2167, 1070, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1070, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateSkill", 2169, 1200, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1200, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateEducation", 2168, 1158, "500/Internal Server Error", 1070, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 88, "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteCertification", 2166, 1065, "500/Internal Server Error", 1065, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["AddCertification", 2166, 1065, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1065, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddLanguage", 2170, 1340, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1340, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddSkill", 2169, 1109, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1109, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateLanguage", 2170, 1409, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1409, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateCertification", 2166, 1163, "500/Internal Server Error", 1065, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 98, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["DeleteLanguage", 2169, 1340, "500/Internal Server Error", 1340, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteSkill", 2168, 1109, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1109, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["AddEducation", 2168, 1070, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1070, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
