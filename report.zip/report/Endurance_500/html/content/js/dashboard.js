/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 60.70009382416248, "KoPercent": 39.29990617583752};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.37049506043379876, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.2590863621207069, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [0.6740580193397799, 500, 1500, "SignOut"], "isController": false}, {"data": [0.21923974658219406, 500, 1500, "UpdateSkill"], "isController": false}, {"data": [0.21790596865621875, 500, 1500, "UpdateEducation"], "isController": false}, {"data": [0.26492164054684897, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [0.855785261753918, 500, 1500, "DescriptionEdit"], "isController": false}, {"data": [0.08602867622540847, 500, 1500, "ManageListingsView"], "isController": false}, {"data": [0.2185728576192064, 500, 1500, "ManageListingsEnable/Disable"], "isController": false}, {"data": [0.26375458486162057, 500, 1500, "AddCertification"], "isController": false}, {"data": [0.17105701900633544, 500, 1500, "AddLanguage"], "isController": false}, {"data": [0.2587529176392131, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.14671557185728576, 500, 1500, "UpdateLanguage"], "isController": false}, {"data": [0.22524174724908302, 500, 1500, "UpdateCertification"], "isController": false}, {"data": [0.023006573306659044, 500, 1500, "SignIn"], "isController": false}, {"data": [0.9305323996887852, 500, 1500, "GetLanguage"], "isController": false}, {"data": [0.16972324108036013, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [0.25841947315771924, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [0.15171723907969323, 500, 1500, "SearchSkillsByCategories"], "isController": false}, {"data": [0.26092030676892297, 500, 1500, "AddEducation"], "isController": false}, {"data": [0.22324108036012005, 500, 1500, "ManageListingsDelete"], "isController": false}, {"data": [0.21007002334111372, 500, 1500, "ShareSkillAddNew"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 72476, 28483, 39.29990617583752, 12441.05909542482, 0, 296602, 44.0, 47869.900000000016, 127076.05000000012, 266818.63000000006, 37.4086668194478, 25.239123663261868, 22.42494191349078], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 2999, 2185, 72.85761920640213, 238.11370456818915, 2, 7686, 42.0, 701.0, 985.0, 1667.0, 1.7704548339202382, 0.3761637703928474, 0.9456856647544298], "isController": false}, {"data": ["SignOut", 2999, 81, 2.700900300100033, 1358.066022007336, 2, 11700, 79.0, 4945.0, 7578.0, 10569.0, 1.7707485796813243, 0.35360931914746635, 0.8627153348583578], "isController": false}, {"data": ["UpdateSkill", 2999, 2304, 76.82560853617872, 199.22874291430497, 1, 2426, 56.0, 589.0, 827.0, 1430.0, 1.7708594130123625, 0.4315158531110794, 1.085884370342563], "isController": false}, {"data": ["UpdateEducation", 2999, 2301, 76.72557519173057, 263.39513171056944, 1, 3146, 74.0, 699.0, 1131.0, 2164.0, 1.7706544867995022, 0.24431071524935585, 1.2483943941722502], "isController": false}, {"data": ["DeleteCertification", 2999, 2164, 72.15738579526509, 265.9423141047016, 1, 8061, 35.0, 903.0, 1167.0, 2049.0, 1.7703304656222956, 0.24718180095558884, 0.9440719838341497], "isController": false}, {"data": ["DescriptionEdit", 2999, 81, 2.700900300100033, 288.13171057019, 2, 9808, 49.0, 991.0, 1299.0, 2050.0, 1.7700786472089833, 0.3770222052942999, 1.6298839796889524], "isController": false}, {"data": ["ManageListingsView", 2999, 81, 2.700900300100033, 30675.149716572192, 2, 162087, 28049.0, 50176.0, 78346.0, 145195.0, 1.7687976776199617, 9.533771884005445, 0.9705873614422159], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2999, 81, 2.700900300100033, 7437.438812937646, 2, 126136, 3666.0, 9155.0, 12303.0, 119967.0, 1.7692140241625436, 0.3257009631199402, 0.9338331413341844], "isController": false}, {"data": ["AddCertification", 2999, 2164, 72.15738579526509, 247.57452484161385, 1, 9635, 44.0, 755.0, 1032.0, 1819.0, 1.7705969905164725, 0.374476983124717, 1.1168189777119684], "isController": false}, {"data": ["AddLanguage", 2999, 2473, 82.46082027342447, 139.3591197065687, 2, 8221, 29.0, 394.0, 529.0, 913.0, 1.7690491316676311, 0.4031781463149332, 0.9862736244964639], "isController": false}, {"data": ["AddSkill", 2999, 2196, 73.22440813604535, 175.635211737246, 2, 3491, 38.0, 521.0, 736.0, 1256.0, 1.771280915466962, 0.3907755398671096, 1.0446001753414544], "isController": false}, {"data": ["Debug Sampler", 2999, 0, 0.0, 0.2677559186395467, 0, 11, 0.0, 1.0, 1.0, 2.0, 1.7691597523530296, 2.034366418557595, 0.0], "isController": false}, {"data": ["UpdateLanguage", 2999, 2533, 84.46148716238746, 162.09936645548467, 1, 12039, 40.0, 450.0, 608.0, 959.0, 1.7684743355985215, 0.37609886517491325, 1.0408834104989233], "isController": false}, {"data": ["UpdateCertification", 2999, 2276, 75.891963987996, 280.8679559853281, 1, 9858, 51.0, 884.0, 1210.0, 2104.0, 1.7704914161569887, 0.22764857900205443, 1.1585532595653174], "isController": false}, {"data": ["SignIn", 3499, 304, 8.688196627607889, 146984.24092597864, 172, 296602, 152620.0, 249403.0, 268196.0, 277008.0, 1.8060175120211912, 0.8093532925624493, 0.9685999407650515], "isController": false}, {"data": ["GetLanguage", 8997, 243, 2.700900300100033, 164.64866066466604, 1, 14464, 29.0, 461.0, 592.0, 1048.3400000000074, 5.299494789743118, 1.4583543635128282, 2.5405313913117618], "isController": false}, {"data": ["DeleteLanguage", 2999, 2473, 82.46082027342447, 163.80360120040035, 1, 2666, 39.0, 491.0, 635.0, 986.0, 1.771593772779955, 0.22392751086053736, 0.9403417486129703], "isController": false}, {"data": ["DeleteSkill", 2999, 2196, 73.22440813604535, 189.5621873957984, 1, 2458, 46.0, 548.0, 785.0, 1434.0, 1.7709681686334906, 0.4222134138437863, 1.0859510588827723], "isController": false}, {"data": ["SearchSkillsByCategories", 2999, 0, 0.0, 26974.66988996327, 59, 163690, 27050.0, 57493.0, 69998.0, 123922.0, 1.769765280380036, 9.021655042562294, 1.216534981116209], "isController": false}, {"data": ["AddEducation", 2999, 2185, 72.85761920640213, 220.19873291097053, 2, 4034, 55.0, 600.0, 872.0, 1734.0, 1.7706273062730629, 0.3746771217712177, 1.1462332795202952], "isController": false}, {"data": ["ManageListingsDelete", 2999, 81, 2.700900300100033, 6223.161387129029, 2, 126536, 4255.0, 9085.0, 17881.0, 104974.0, 1.7693549376743396, 0.3432437127869081, 0.9442748329171996], "isController": false}, {"data": ["Transaction Controller", 0, 0, NaN, NaN, 9223372036854775807, -9223372036854775808, NaN, NaN, NaN, NaN, 0.0, 0.0, 0.0], "isController": true}, {"data": ["ShareSkillAddNew", 2999, 81, 2.700900300100033, 53173.22474158053, 4, 136977, 72571.0, 114474.0, 122277.0, 126463.0, 1.7691451412808987, 0.38354744239364924, 2.6880927414169324], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 17816, 62.54959098409578, 24.581930570119763], "isController": false}, {"data": ["500/Internal Server Error", 8966, 31.478425727627005, 12.370991776588111], "isController": false}, {"data": ["401/Unauthorized", 1701, 5.971983288277218, 2.346983829129643], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 72476, 28483, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 17816, "500/Internal Server Error", 8966, "401/Unauthorized", 1701, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["DeleteEducation", 2999, 2185, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2104, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["SignOut", 2999, 81, "401/Unauthorized", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateSkill", 2999, 2304, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2223, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateEducation", 2999, 2301, "500/Internal Server Error", 2104, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 116, "401/Unauthorized", 81, "", "", "", ""], "isController": false}, {"data": ["DeleteCertification", 2999, 2164, "500/Internal Server Error", 2083, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["DescriptionEdit", 2999, 81, "401/Unauthorized", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsView", 2999, 81, "401/Unauthorized", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2999, 81, "401/Unauthorized", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddCertification", 2999, 2164, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2083, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["AddLanguage", 2999, 2473, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2392, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["AddSkill", 2999, 2196, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2115, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateLanguage", 2999, 2533, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2452, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateCertification", 2999, 2276, "500/Internal Server Error", 2083, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 112, "401/Unauthorized", 81, "", "", "", ""], "isController": false}, {"data": ["SignIn", 3499, 304, "500/Internal Server Error", 304, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetLanguage", 8997, 243, "401/Unauthorized", 243, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteLanguage", 2999, 2473, "500/Internal Server Error", 2392, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteSkill", 2999, 2196, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2115, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["AddEducation", 2999, 2185, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2104, "401/Unauthorized", 81, "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsDelete", 2999, 81, "401/Unauthorized", 81, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["ShareSkillAddNew", 2999, 81, "401/Unauthorized", 81, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
