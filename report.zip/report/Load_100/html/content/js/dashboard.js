/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 91.29166666666667, "KoPercent": 8.708333333333334};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9127083333333333, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.88, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [1.0, 500, 1500, "SignOut"], "isController": false}, {"data": [0.87, 500, 1500, "UpdateSkill"], "isController": false}, {"data": [0.86, 500, 1500, "UpdateEducation"], "isController": false}, {"data": [0.82, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [1.0, 500, 1500, "DescriptionEdit"], "isController": false}, {"data": [0.995, 500, 1500, "ManageListingsView"], "isController": false}, {"data": [1.0, 500, 1500, "ManageListingsEnable/Disable"], "isController": false}, {"data": [0.82, 500, 1500, "AddCertification"], "isController": false}, {"data": [0.74, 500, 1500, "AddLanguage"], "isController": false}, {"data": [0.93, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.64, 500, 1500, "UpdateLanguage"], "isController": false}, {"data": [0.82, 500, 1500, "UpdateCertification"], "isController": false}, {"data": [0.98, 500, 1500, "SignIn"], "isController": false}, {"data": [1.0, 500, 1500, "GetLanguage"], "isController": false}, {"data": [0.74, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [0.93, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [1.0, 500, 1500, "SearchSkillsByCategories"], "isController": false}, {"data": [0.88, 500, 1500, "AddEducation"], "isController": false}, {"data": [1.0, 500, 1500, "ManageListingsDelete"], "isController": false}, {"data": [1.0, 500, 1500, "ShareSkillAddNew"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2400, 209, 8.708333333333334, 26.56416666666669, 0, 582, 7.0, 85.80000000000018, 177.0, 254.97999999999956, 18.55316254116483, 12.793808232289459, 11.136608288625364], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 100, 12, 12.0, 6.609999999999999, 3, 34, 5.0, 9.900000000000006, 13.0, 33.86999999999993, 0.8558346527450896, 0.18239976036629724, 0.4707090590097993], "isController": false}, {"data": ["SignOut", 100, 0, 0.0, 4.96, 3, 49, 4.0, 6.0, 8.0, 48.62999999999981, 0.8590105916005945, 0.17280877135715084, 0.4244720306151375], "isController": false}, {"data": ["UpdateSkill", 100, 13, 13.0, 10.269999999999996, 5, 76, 9.0, 11.900000000000006, 15.949999999999989, 75.57999999999979, 0.8536137739118559, 0.17756666990328557, 0.5376349643402846], "isController": false}, {"data": ["UpdateEducation", 100, 14, 14.0, 9.629999999999995, 4, 26, 9.0, 12.0, 15.899999999999977, 25.97999999999999, 0.8572726727190118, 0.17183963750225034, 0.6180065302745844], "isController": false}, {"data": ["DeleteCertification", 100, 18, 18.0, 5.879999999999998, 4, 20, 5.0, 7.0, 10.849999999999966, 19.97999999999999, 0.8582364956487409, 0.17000458083729553, 0.4704376416090218], "isController": false}, {"data": ["DescriptionEdit", 100, 0, 0.0, 9.519999999999998, 6, 71, 8.0, 10.0, 15.949999999999989, 70.66999999999983, 0.855820003936772, 0.18386757897079087, 0.7939736364647788], "isController": false}, {"data": ["ManageListingsView", 100, 0, 0.0, 178.60999999999993, 129, 523, 161.0, 225.9, 298.69999999999993, 521.5999999999992, 0.854678939856243, 4.7372249536336675, 0.47491437185371316], "isController": false}, {"data": ["ManageListingsEnable/Disable", 100, 0, 0.0, 8.839999999999996, 6, 35, 8.0, 11.0, 13.899999999999977, 34.84999999999992, 0.8548031388371259, 0.1584474451002684, 0.4574532422683056], "isController": false}, {"data": ["AddCertification", 100, 18, 18.0, 5.3199999999999985, 3, 20, 5.0, 6.900000000000006, 7.949999999999989, 19.91999999999996, 0.8566998209497374, 0.17558999845794032, 0.5463134600392369], "isController": false}, {"data": ["AddLanguage", 100, 26, 26.0, 11.080000000000004, 5, 338, 7.0, 10.900000000000006, 15.0, 334.8499999999984, 0.8407600470825627, 0.17742992790482598, 0.4745696359508996], "isController": false}, {"data": ["AddSkill", 100, 7, 7.0, 5.489999999999999, 3, 28, 5.0, 7.0, 11.0, 27.849999999999923, 0.8548250600514604, 0.1744961741235906, 0.5100567496986741], "isController": false}, {"data": ["Debug Sampler", 100, 0, 0.0, 0.3600000000000001, 0, 8, 0.0, 1.0, 1.0, 7.989999999999995, 0.8557687370564979, 1.0231534248934568, 0.0], "isController": false}, {"data": ["UpdateLanguage", 100, 36, 36.0, 10.94, 4, 179, 9.0, 11.900000000000006, 23.59999999999991, 177.70999999999935, 0.8407176365745801, 0.17980191641585258, 0.5080758810720831], "isController": false}, {"data": ["UpdateCertification", 100, 18, 18.0, 10.149999999999999, 4, 71, 9.0, 12.900000000000006, 19.749999999999943, 70.67999999999984, 0.8572065353426255, 0.13685168398223868, 0.573675428388966], "isController": false}, {"data": ["SignIn", 100, 2, 2.0, 213.32000000000002, 161, 582, 190.0, 271.00000000000006, 287.95, 581.3999999999996, 0.8404350091607415, 0.40380275830770007, 0.27002257618543357], "isController": false}, {"data": ["GetLanguage", 300, 0, 0.0, 5.51333333333333, 3, 61, 4.0, 7.0, 8.949999999999989, 38.8900000000001, 2.479564257907744, 0.6753018998627974, 1.2058818363652895], "isController": false}, {"data": ["DeleteLanguage", 100, 26, 26.0, 5.659999999999999, 4, 11, 5.0, 7.900000000000006, 9.0, 11.0, 0.853905336054445, 0.15360289345823122, 0.46622897791800805], "isController": false}, {"data": ["DeleteSkill", 100, 7, 7.0, 6.380000000000002, 3, 67, 5.0, 8.0, 11.949999999999989, 66.45999999999972, 0.855856626897862, 0.1743306398812071, 0.5390475893728283], "isController": false}, {"data": ["SearchSkillsByCategories", 100, 0, 0.0, 86.54, 62, 269, 77.0, 111.80000000000001, 139.5499999999999, 268.16999999999956, 0.8567365192508696, 4.367348271962441, 0.5948629542845394], "isController": false}, {"data": ["AddEducation", 100, 12, 12.0, 5.48, 3, 16, 5.0, 7.0, 10.949999999999989, 15.97999999999999, 0.8582512272992551, 0.17510336563218784, 0.5615510959868172], "isController": false}, {"data": ["ManageListingsDelete", 100, 0, 0.0, 10.780000000000003, 8, 32, 10.0, 13.0, 17.94999999999999, 31.929999999999964, 0.8567511994516792, 0.1673342186429061, 0.4635157856408499], "isController": false}, {"data": ["Transaction Controller", 0, 0, NaN, NaN, 9223372036854775807, -9223372036854775808, NaN, NaN, NaN, NaN, 0.0, 0.0, 0.0], "isController": true}, {"data": ["ShareSkillAddNew", 100, 0, 0.0, 15.180000000000005, 10, 29, 14.0, 20.80000000000001, 23.94999999999999, 28.989999999999995, 0.8555637309423179, 0.18715456614363202, 1.3059044057254325], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 522 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.4784688995215311, 0.041666666666666664], "isController": false}, {"data": ["Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 133, 63.63636363636363, 5.541666666666667], "isController": false}, {"data": ["500/Internal Server Error", 74, 35.4066985645933, 3.0833333333333335], "isController": false}, {"data": ["The operation lasted too long: It took 582 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.4784688995215311, 0.041666666666666664], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2400, 209, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 133, "500/Internal Server Error", 74, "The operation lasted too long: It took 522 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, "The operation lasted too long: It took 582 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["DeleteEducation", 100, 12, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 12, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateSkill", 100, 13, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 13, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateEducation", 100, 14, "500/Internal Server Error", 12, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2, "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteCertification", 100, 18, "500/Internal Server Error", 18, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["AddCertification", 100, 18, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 18, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddLanguage", 100, 26, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 26, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddSkill", 100, 7, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateLanguage", 100, 36, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 36, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateCertification", 100, 18, "500/Internal Server Error", 18, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["SignIn", 100, 2, "The operation lasted too long: It took 522 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, "The operation lasted too long: It took 582 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["DeleteLanguage", 100, 26, "500/Internal Server Error", 26, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteSkill", 100, 7, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["AddEducation", 100, 12, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 12, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
