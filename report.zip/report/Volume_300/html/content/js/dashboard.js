/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9974121996303142, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler_CheckTheId"], "isController": false}, {"data": [1.0, 500, 1500, "GetSkill"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [1.0, 500, 1500, "AddCertification"], "isController": false}, {"data": [1.0, 500, 1500, "AddLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "GetEducation"], "isController": false}, {"data": [0.9766666666666667, 500, 1500, "SignIn"], "isController": false}, {"data": [1.0, 500, 1500, "GetLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "AddEducation"], "isController": false}, {"data": [1.0, 500, 1500, "GetCertification"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 2705, 0, 0.0, 43.152310536044354, 5, 802, 8.0, 257.0, 291.6999999999998, 420.4600000000005, 22.147623531338272, 8.264676382691285, 13.34357697169116], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 300, 0, 0.0, 6.706666666666666, 5, 16, 6.0, 8.900000000000034, 10.0, 13.0, 140.3180542563143, 29.872398269410667, 77.4215826707203], "isController": false}, {"data": ["Debug Sampler_CheckTheId", 1, 0, 0.0, 56.0, 56, 56, 56.0, 56.0, 56.0, 56.0, 17.857142857142858, 870.1695033482142, 0.0], "isController": false}, {"data": ["GetSkill", 1, 0, 0.0, 15.0, 15, 15, 15.0, 15.0, 15.0, 15.0, 66.66666666666667, 2858.854166666667, 32.2265625], "isController": false}, {"data": ["DeleteCertification", 300, 0, 0.0, 7.400000000000001, 5, 26, 7.0, 10.0, 12.0, 18.99000000000001, 127.11864406779661, 29.669292902542374, 70.26284427966102], "isController": false}, {"data": ["AddCertification", 300, 0, 0.0, 11.536666666666664, 6, 105, 10.0, 16.0, 18.94999999999999, 46.830000000000155, 2.751763421726089, 0.5562646760715826, 1.8165938213738637], "isController": false}, {"data": ["AddLanguage", 300, 0, 0.0, 9.879999999999995, 6, 74, 9.0, 12.0, 15.949999999999989, 37.92000000000007, 2.679959264619178, 0.5417495779064159, 1.5833743702095728], "isController": false}, {"data": ["AddSkill", 300, 0, 0.0, 9.033333333333328, 5, 52, 8.0, 12.0, 15.0, 38.91000000000008, 2.7496448375418177, 0.5558364075890198, 1.7265836235736216], "isController": false}, {"data": ["GetEducation", 1, 0, 0.0, 17.0, 17, 17, 17.0, 17.0, 17.0, 17.0, 58.8235294117647, 9405.445772058823, 28.664981617647058], "isController": false}, {"data": ["SignIn", 300, 0, 0.0, 317.53000000000026, 238, 802, 283.0, 409.0, 496.0499999999998, 717.8300000000002, 2.6635650930916, 1.2797597908213547, 1.5401857059779278], "isController": false}, {"data": ["GetLanguage", 1, 0, 0.0, 11.0, 11, 11, 11.0, 11.0, 11.0, 11.0, 90.9090909090909, 3782.492897727273, 44.21164772727273], "isController": false}, {"data": ["DeleteSkill", 300, 0, 0.0, 8.443333333333346, 5, 29, 7.0, 12.0, 15.949999999999989, 24.0, 113.33585190782017, 25.23493577635059, 71.60966424253873], "isController": false}, {"data": ["DeleteLanguage", 300, 0, 0.0, 6.97666666666667, 5, 19, 6.0, 9.0, 10.949999999999989, 15.990000000000009, 136.92377909630304, 31.28922295755363, 75.28133557736194], "isController": false}, {"data": ["AddEducation", 300, 0, 0.0, 11.213333333333322, 5, 79, 10.0, 16.0, 20.0, 49.86000000000013, 2.7507541651002647, 0.5560606564216356, 1.8777120716846534], "isController": false}, {"data": ["GetCertification", 1, 0, 0.0, 12.0, 12, 12, 12.0, 12.0, 12.0, 12.0, 83.33333333333333, 5028.076171875, 40.934244791666664], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 2705, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
