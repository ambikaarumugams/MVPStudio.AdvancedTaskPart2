/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 63.74738727978501, "KoPercent": 36.25261272021499};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.40376231710958493, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.2876934148974451, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [0.930580598629643, 500, 1500, "SignOut"], "isController": false}, {"data": [0.23083843109032026, 500, 1500, "UpdateSkill"], "isController": false}, {"data": [0.24037423533645197, 500, 1500, "UpdateEducation"], "isController": false}, {"data": [0.29363080244692336, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [0.7837351565311264, 500, 1500, "DescriptionEdit"], "isController": false}, {"data": [0.10921194674343289, 500, 1500, "ManageListingsView"], "isController": false}, {"data": [0.31180280676502337, 500, 1500, "ManageListingsEnable/Disable"], "isController": false}, {"data": [0.29686937747391146, 500, 1500, "AddCertification"], "isController": false}, {"data": [0.20169125584742714, 500, 1500, "AddLanguage"], "isController": false}, {"data": [0.2788772939906441, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.17002518891687657, 500, 1500, "UpdateLanguage"], "isController": false}, {"data": [0.24397265203310545, 500, 1500, "UpdateCertification"], "isController": false}, {"data": [0.0021151968760169215, 500, 1500, "SignIn"], "isController": false}, {"data": [0.8975650713685979, 500, 1500, "GetLanguage"], "isController": false}, {"data": [0.19755307664627564, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [0.2797768981648075, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [0.2064121037463977, 500, 1500, "SearchSkillsByCategories"], "isController": false}, {"data": [0.2893127024109392, 500, 1500, "AddEducation"], "isController": false}, {"data": [0.34755219582433405, 500, 1500, "ManageListingsDelete"], "isController": false}, {"data": [0.3389708528247571, 500, 1500, "ShareSkillAddNew"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 66980, 24282, 36.25261272021499, 7758.228247238016, 0, 318855, 152.0, 7865.000000000015, 46762.00000000055, 136015.06000000032, 35.301980031032855, 24.173306025917018, 21.363007252671366], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 2779, 1895, 68.1899964015833, 383.77473911478927, 2, 14990, 100.0, 965.0, 1360.0, 2175.1999999999944, 1.5597349292506704, 0.333324543220485, 0.8419889270536276], "isController": false}, {"data": ["SignOut", 2773, 21, 0.7573025604038947, 252.16588532275534, 3, 11192, 28.0, 401.1999999999998, 1104.2999999999943, 7589.679999999996, 1.5696374494099001, 0.3151969962570401, 0.7725686459895847], "isController": false}, {"data": ["UpdateSkill", 2779, 2039, 73.3717164447643, 416.82619647355114, 3, 14968, 119.0, 945.0, 1374.0, 2596.7999999999947, 1.5602375783136522, 0.380270407376965, 0.9654143272226368], "isController": false}, {"data": ["UpdateEducation", 2779, 2016, 72.544080604534, 405.04282115868983, 3, 14863, 166.0, 1062.0, 1488.0, 2420.399999999994, 1.5597883312790601, 0.22170489891544476, 1.1085831436217624], "isController": false}, {"data": ["DeleteCertification", 2779, 1881, 67.68621806405181, 474.5681899964021, 4, 14923, 138.0, 1126.0, 1479.0, 2493.7999999999956, 1.5590664002957682, 0.22408358039121962, 0.8402205628038959], "isController": false}, {"data": ["DescriptionEdit", 2779, 21, 0.7556675062972292, 652.046779417056, 4, 15070, 169.0, 1431.0, 2198.0, 13815.199999999997, 1.5589876846143793, 0.33413343474607127, 1.4433007418164365], "isController": false}, {"data": ["ManageListingsView", 2779, 21, 0.7556675062972292, 16511.513853904275, 3, 153103, 7217.0, 64330.0, 76768.0, 113301.59999999966, 1.5575695413605053, 8.560940118485139, 0.8624624479455663], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2779, 21, 0.7556675062972292, 7271.321338611023, 2, 94473, 3279.0, 17157.0, 25069.0, 73899.59999999995, 1.5578480730949715, 0.287983048872368, 0.830496177624391], "isController": false}, {"data": ["AddCertification", 2779, 1881, 67.68621806405181, 371.2882331774026, 3, 14941, 118.0, 1010.0, 1366.0, 2135.199999999997, 1.5598461146416733, 0.33097704096237845, 0.9916791660632717], "isController": false}, {"data": ["AddLanguage", 2779, 2179, 78.40949982007916, 276.3857502698818, 5, 14809, 55.0, 582.0, 1058.0, 2177.7999999999956, 1.5580210049712027, 0.355648893112695, 0.8764059778263729], "isController": false}, {"data": ["AddSkill", 2779, 1927, 69.34148974451242, 339.3861101115504, 2, 14943, 78.0, 823.0, 1197.0, 2040.3999999999924, 1.5603935178816382, 0.3450834005489171, 0.9280266647472909], "isController": false}, {"data": ["Debug Sampler", 2779, 0, 0.0, 0.3979848866498732, 0, 35, 0.0, 1.0, 1.0, 2.0, 1.5580341074353938, 1.8086722535233772, 0.0], "isController": false}, {"data": ["UpdateLanguage", 2779, 2249, 80.92839150773659, 267.6926952141061, 5, 14963, 74.0, 766.0, 1093.0, 2134.5999999999995, 1.5579022193519596, 0.33329311041709064, 0.9257150446740654], "isController": false}, {"data": ["UpdateCertification", 2779, 2003, 72.07628643396906, 432.2180640518173, 2, 14855, 180.0, 1163.0, 1463.0, 2408.9999999999927, 1.5591521219673257, 0.20415568882936794, 1.0290703376638752], "isController": false}, {"data": ["SignIn", 3073, 22, 0.7159127888057273, 109616.9814513505, 348, 318855, 100963.0, 204359.0, 217917.9, 233688.83999999997, 1.6196324967955205, 0.7738685878127529, 0.8945198730765217], "isController": false}, {"data": ["GetLanguage", 8337, 63, 0.7556675062972292, 260.12198632601707, 3, 14703, 57.0, 750.0, 1093.0999999999995, 1895.8600000000024, 4.668169156039587, 1.375340444202584, 2.2612018500566933], "isController": false}, {"data": ["DeleteLanguage", 2779, 2179, 78.40949982007916, 323.61892767182434, 5, 15030, 88.0, 854.0, 1377.0, 1918.199999999998, 1.5605179414640118, 0.2022024346662968, 0.8370276409688464], "isController": false}, {"data": ["DeleteSkill", 2779, 1927, 69.34148974451242, 376.8758546239659, 3, 14969, 85.0, 816.0, 1220.0, 2186.999999999999, 1.560047514365461, 0.3717936644892992, 0.9652967230441304], "isController": false}, {"data": ["SearchSkillsByCategories", 2776, 0, 0.0, 12209.117074927939, 81, 164122, 5019.0, 40040.00000000001, 48323.950000000004, 84440.63, 1.5570409267310161, 7.937259411656157, 1.078084260712649], "isController": false}, {"data": ["AddEducation", 2779, 1895, 68.1899964015833, 339.9964015833028, 3, 14861, 102.0, 886.0, 1282.0, 1997.7999999999938, 1.559913533975972, 0.3311141355446422, 1.0176190302364456], "isController": false}, {"data": ["ManageListingsDelete", 2778, 21, 0.755939524838013, 6220.022678185752, 2, 104526, 2417.5, 18050.899999999994, 24511.449999999975, 66389.09000000001, 1.5581600922556416, 0.303753008839109, 0.839791210123329], "isController": false}, {"data": ["Transaction Controller", 0, 0, NaN, NaN, 9223372036854775807, -9223372036854775808, NaN, NaN, NaN, NaN, 0.0, 0.0, 0.0], "isController": true}, {"data": ["ShareSkillAddNew", 2779, 21, 0.7556675062972292, 17487.92731198271, 6, 110282, 2207.0, 71555.0, 73529.0, 86462.5999999999, 1.558638807470249, 0.3401010854245118, 2.3760300865944726], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 16067, 66.16835516020097, 23.98775753956405], "isController": false}, {"data": ["500/Internal Server Error", 7774, 32.01548472119266, 11.606449686473574], "isController": false}, {"data": ["401/Unauthorized", 441, 1.8161601186063752, 0.6584054941773664], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 66980, 24282, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 16067, "500/Internal Server Error", 7774, "401/Unauthorized", 441, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["DeleteEducation", 2779, 1895, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1874, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["SignOut", 2773, 21, "401/Unauthorized", 21, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateSkill", 2779, 2039, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2018, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateEducation", 2779, 2016, "500/Internal Server Error", 1874, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 121, "401/Unauthorized", 21, "", "", "", ""], "isController": false}, {"data": ["DeleteCertification", 2779, 1881, "500/Internal Server Error", 1860, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["DescriptionEdit", 2779, 21, "401/Unauthorized", 21, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsView", 2779, 21, "401/Unauthorized", 21, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsEnable/Disable", 2779, 21, "401/Unauthorized", 21, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddCertification", 2779, 1881, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1860, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["AddLanguage", 2779, 2179, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2158, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["AddSkill", 2779, 1927, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1906, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateLanguage", 2779, 2249, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 2228, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateCertification", 2779, 2003, "500/Internal Server Error", 1860, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 122, "401/Unauthorized", 21, "", "", "", ""], "isController": false}, {"data": ["SignIn", 3073, 22, "500/Internal Server Error", 22, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GetLanguage", 8337, 63, "401/Unauthorized", 63, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteLanguage", 2779, 2179, "500/Internal Server Error", 2158, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteSkill", 2779, 1927, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1906, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["AddEducation", 2779, 1895, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1874, "401/Unauthorized", 21, "", "", "", "", "", ""], "isController": false}, {"data": ["ManageListingsDelete", 2778, 21, "401/Unauthorized", 21, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["ShareSkillAddNew", 2779, 21, "401/Unauthorized", 21, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
