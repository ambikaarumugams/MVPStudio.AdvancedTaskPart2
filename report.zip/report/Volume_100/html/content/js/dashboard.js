/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.943646408839779, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler_CheckTheId"], "isController": false}, {"data": [1.0, 500, 1500, "GetSkill"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [1.0, 500, 1500, "AddCertification"], "isController": false}, {"data": [1.0, 500, 1500, "AddLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "GetEducation"], "isController": false}, {"data": [0.49, 500, 1500, "SignIn"], "isController": false}, {"data": [1.0, 500, 1500, "GetLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "AddEducation"], "isController": false}, {"data": [1.0, 500, 1500, "GetCertification"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 905, 0, 0.0, 96.14143646408853, 10, 1595, 18.0, 545.0, 596.7999999999997, 1105.0199999999982, 9.596725448819232, 3.90625, 5.7725227292609995], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 100, 0, 0.0, 26.899999999999995, 12, 131, 22.0, 44.80000000000001, 56.849999999999966, 130.8499999999999, 35.1741118536757, 7.488238656348927, 19.40759101301442], "isController": false}, {"data": ["Debug Sampler_CheckTheId", 1, 0, 0.0, 68.0, 68, 68, 68.0, 68.0, 68.0, 68.0, 14.705882352941176, 248.43462775735293, 0.0], "isController": false}, {"data": ["GetSkill", 1, 0, 0.0, 20.0, 20, 20, 20.0, 20.0, 20.0, 20.0, 50.0, 929.541015625, 24.169921875], "isController": false}, {"data": ["DeleteCertification", 100, 0, 0.0, 18.45999999999999, 10, 56, 16.0, 27.900000000000006, 33.94999999999999, 55.84999999999992, 50.27652086475616, 11.734461412770235, 27.789561337355455], "isController": false}, {"data": ["AddCertification", 100, 0, 0.0, 25.079999999999995, 14, 86, 22.0, 35.900000000000006, 53.69999999999993, 85.82999999999991, 1.2561393812257406, 0.2539266131970004, 0.8292482633873055], "isController": false}, {"data": ["AddLanguage", 100, 0, 0.0, 19.510000000000005, 10, 151, 15.5, 25.900000000000006, 34.94999999999999, 150.70999999999987, 1.1824663883929099, 0.23903373280989487, 0.6986251611110454], "isController": false}, {"data": ["AddSkill", 100, 0, 0.0, 19.680000000000003, 12, 80, 16.0, 30.0, 39.94999999999999, 79.7999999999999, 1.2528659308167434, 0.2532648903115878, 0.7867117124171543], "isController": false}, {"data": ["GetEducation", 1, 0, 0.0, 29.0, 29, 29, 29.0, 29.0, 29.0, 29.0, 34.48275862068965, 2369.6794181034484, 16.803609913793103], "isController": false}, {"data": ["SignIn", 100, 0, 0.0, 704.2099999999996, 533, 1595, 587.0, 1073.1000000000001, 1271.9499999999994, 1594.81, 1.1657864978607817, 0.5601239813940475, 0.6721032391377844], "isController": false}, {"data": ["GetLanguage", 1, 0, 0.0, 19.0, 19, 19, 19.0, 19.0, 19.0, 19.0, 52.63157894736842, 848.5814144736843, 25.596217105263158], "isController": false}, {"data": ["DeleteSkill", 100, 0, 0.0, 15.74, 10, 32, 15.0, 23.0, 26.899999999999977, 31.97999999999999, 59.31198102016608, 13.206183274021353, 37.47544113285884], "isController": false}, {"data": ["DeleteLanguage", 100, 0, 0.0, 16.130000000000006, 10, 47, 15.0, 21.0, 24.94999999999999, 46.949999999999974, 58.20721769499418, 13.301258731082655, 32.00260113504075], "isController": false}, {"data": ["AddEducation", 100, 0, 0.0, 22.720000000000006, 13, 84, 19.5, 35.80000000000001, 40.849999999999966, 83.64999999999982, 1.2549255829129333, 0.25368124576462614, 0.8566337719298245], "isController": false}, {"data": ["GetCertification", 1, 0, 0.0, 29.0, 29, 29, 29.0, 29.0, 29.0, 29.0, 34.48275862068965, 1013.4698275862069, 16.93830818965517], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 905, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
