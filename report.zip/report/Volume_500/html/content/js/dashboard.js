/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9896781354051054, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler_CheckTheId"], "isController": false}, {"data": [1.0, 500, 1500, "GetSkill"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [1.0, 500, 1500, "AddCertification"], "isController": false}, {"data": [1.0, 500, 1500, "AddLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "GetEducation"], "isController": false}, {"data": [0.907, 500, 1500, "SignIn"], "isController": false}, {"data": [1.0, 500, 1500, "GetLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [1.0, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [1.0, 500, 1500, "AddEducation"], "isController": false}, {"data": [1.0, 500, 1500, "GetCertification"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 4505, 0, 0.0, 55.16736958934532, 5, 1588, 11.0, 261.0, 381.0, 595.0, 17.67165631080148, 6.476143049459063, 10.650337883392567], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 500, 0, 0.0, 8.100000000000003, 5, 41, 7.0, 11.0, 13.949999999999989, 22.99000000000001, 118.45534233593935, 25.218031864487088, 65.35866056621653], "isController": false}, {"data": ["Debug Sampler_CheckTheId", 1, 0, 0.0, 379.0, 379, 379, 379.0, 379.0, 379.0, 379.0, 2.638522427440633, 212.5762697889182, 0.0], "isController": false}, {"data": ["GetSkill", 1, 0, 0.0, 26.0, 26, 26, 26.0, 26.0, 26.0, 26.0, 38.46153846153847, 2593.562199519231, 18.592247596153847], "isController": false}, {"data": ["DeleteCertification", 500, 0, 0.0, 9.504000000000005, 5, 46, 8.0, 14.0, 17.0, 28.99000000000001, 100.28078620136382, 23.405378810669877, 55.428637685519455], "isController": false}, {"data": ["AddCertification", 500, 0, 0.0, 15.319999999999995, 6, 80, 13.0, 24.0, 29.94999999999999, 57.91000000000008, 2.2002200220022, 0.4447710396039604, 1.45248899889989], "isController": false}, {"data": ["AddLanguage", 500, 0, 0.0, 12.634000000000011, 5, 90, 10.0, 19.0, 22.94999999999999, 61.99000000000001, 2.174858634188778, 0.4396442746846455, 1.2849506578947367], "isController": false}, {"data": ["AddSkill", 500, 0, 0.0, 11.617999999999997, 5, 59, 10.0, 18.0, 24.0, 44.930000000000064, 2.19932964432441, 0.44459105114761016, 1.3810243762701129], "isController": false}, {"data": ["GetEducation", 1, 0, 0.0, 60.0, 60, 60, 60.0, 60.0, 60.0, 60.0, 16.666666666666668, 4184.261067708334, 8.121744791666668], "isController": false}, {"data": ["SignIn", 500, 0, 0.0, 394.642, 242, 1588, 343.5, 584.1000000000004, 715.6999999999999, 1017.2100000000007, 2.1696303817681617, 1.0424395974901715, 1.2553176284638148], "isController": false}, {"data": ["GetLanguage", 1, 0, 0.0, 17.0, 17, 17, 17.0, 17.0, 17.0, 17.0, 58.8235294117647, 3960.5353860294113, 28.60753676470588], "isController": false}, {"data": ["DeleteSkill", 500, 0, 0.0, 15.377999999999977, 6, 98, 12.0, 27.0, 33.0, 64.87000000000012, 63.22711178553364, 14.077911608497724, 39.94916145042994], "isController": false}, {"data": ["DeleteLanguage", 500, 0, 0.0, 13.065999999999999, 5, 86, 11.0, 20.900000000000034, 27.0, 36.99000000000001, 74.21701053881549, 16.95974654890901, 40.80486028647766], "isController": false}, {"data": ["AddEducation", 500, 0, 0.0, 15.75399999999999, 5, 192, 13.0, 25.0, 31.94999999999999, 58.91000000000008, 2.199803777503047, 0.4446868964288385, 1.5016238676510054], "isController": false}, {"data": ["GetCertification", 1, 0, 0.0, 39.0, 39, 39, 39.0, 39.0, 39.0, 39.0, 25.64102564102564, 2341.1458333333335, 12.595152243589743], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 4505, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
