/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 75.72222222222223, "KoPercent": 24.27777777777778};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7526388888888889, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.5966666666666667, 500, 1500, "DeleteEducation"], "isController": false}, {"data": [1.0, 500, 1500, "SignOut"], "isController": false}, {"data": [0.5333333333333333, 500, 1500, "UpdateSkill"], "isController": false}, {"data": [0.5566666666666666, 500, 1500, "UpdateEducation"], "isController": false}, {"data": [0.6, 500, 1500, "DeleteCertification"], "isController": false}, {"data": [1.0, 500, 1500, "DescriptionEdit"], "isController": false}, {"data": [0.9083333333333333, 500, 1500, "ManageListingsView"], "isController": false}, {"data": [1.0, 500, 1500, "ManageListingsEnable/Disable"], "isController": false}, {"data": [0.6, 500, 1500, "AddCertification"], "isController": false}, {"data": [0.4033333333333333, 500, 1500, "AddLanguage"], "isController": false}, {"data": [0.5966666666666667, 500, 1500, "AddSkill"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.3433333333333333, 500, 1500, "UpdateLanguage"], "isController": false}, {"data": [0.54, 500, 1500, "UpdateCertification"], "isController": false}, {"data": [0.8066666666666666, 500, 1500, "SignIn"], "isController": false}, {"data": [1.0, 500, 1500, "GetLanguage"], "isController": false}, {"data": [0.4033333333333333, 500, 1500, "DeleteLanguage"], "isController": false}, {"data": [0.5966666666666667, 500, 1500, "DeleteSkill"], "isController": false}, {"data": [0.9816666666666667, 500, 1500, "SearchSkillsByCategories"], "isController": false}, {"data": [0.5966666666666667, 500, 1500, "AddEducation"], "isController": false}, {"data": [1.0, 500, 1500, "ManageListingsDelete"], "isController": false}, {"data": [1.0, 500, 1500, "ShareSkillAddNew"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 7200, 1748, 24.27777777777778, 53.95736111111133, 0, 1518, 10.0, 182.90000000000055, 301.0, 609.9499999999989, 37.60655189704162, 25.92319575875136, 22.519100953678652], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["DeleteEducation", 300, 121, 40.333333333333336, 13.233333333333327, 3, 138, 6.0, 30.800000000000068, 45.94999999999999, 99.97000000000003, 1.6874029743289762, 0.36056154310189664, 0.9210682543956847], "isController": false}, {"data": ["SignOut", 300, 0, 0.0, 11.113333333333333, 3, 328, 5.0, 22.0, 33.94999999999999, 83.96000000000004, 1.6771957287415442, 0.33740460949292783, 0.828770545647677], "isController": false}, {"data": ["UpdateSkill", 300, 140, 46.666666666666664, 20.796666666666656, 4, 284, 11.0, 43.80000000000007, 66.89999999999998, 195.72000000000025, 1.683596161400752, 0.3838073124193277, 1.0521653940316515], "isController": false}, {"data": ["UpdateEducation", 300, 133, 44.333333333333336, 20.930000000000014, 4, 233, 11.0, 49.80000000000007, 80.64999999999992, 150.8900000000001, 1.6862553327824898, 0.28824976005991826, 1.2086202163044029], "isController": false}, {"data": ["DeleteCertification", 300, 120, 40.0, 14.883333333333331, 4, 280, 7.0, 31.0, 50.94999999999999, 128.7800000000002, 1.6843429097585214, 0.29242429931334957, 0.9178352965285693], "isController": false}, {"data": ["DescriptionEdit", 300, 0, 0.0, 20.666666666666668, 6, 334, 10.0, 45.0, 69.89999999999998, 172.74000000000024, 1.682227268904029, 0.36141601480359997, 1.5606600639246362], "isController": false}, {"data": ["ManageListingsView", 300, 0, 0.0, 371.0233333333336, 149, 1383, 286.0, 619.9000000000003, 929.7499999999995, 1217.8400000000001, 1.6753131439484896, 9.291732792090846, 0.9309113075260651], "isController": false}, {"data": ["ManageListingsEnable/Disable", 300, 0, 0.0, 19.013333333333318, 6, 193, 11.0, 35.7000000000001, 60.0, 155.72000000000025, 1.6758372203446639, 0.3104062945144262, 0.8968347624500741], "isController": false}, {"data": ["AddCertification", 300, 120, 40.0, 16.176666666666662, 3, 420, 7.0, 33.80000000000007, 52.89999999999998, 152.7900000000002, 1.685308046222382, 0.3512155635389222, 1.0747130411945465], "isController": false}, {"data": ["AddLanguage", 300, 179, 59.666666666666664, 15.989999999999988, 5, 193, 9.0, 35.900000000000034, 53.94999999999999, 93.88000000000011, 1.6746211169722849, 0.3726740646543303, 0.9452451226659968], "isController": false}, {"data": ["AddSkill", 300, 121, 40.333333333333336, 13.096666666666653, 3, 200, 6.0, 23.900000000000034, 46.799999999999955, 127.93000000000006, 1.6852512428727915, 0.35992073175013345, 1.005555184956324], "isController": false}, {"data": ["Debug Sampler", 300, 0, 0.0, 0.49333333333333307, 0, 13, 0.0, 1.0, 1.0, 9.930000000000064, 1.6740604335816525, 1.9739853624340837, 0.0], "isController": false}, {"data": ["UpdateLanguage", 300, 197, 65.66666666666667, 18.79666666666666, 4, 216, 9.5, 40.600000000000136, 61.0, 204.83000000000015, 1.6730801405387319, 0.35880271073838604, 1.0023013565891472], "isController": false}, {"data": ["UpdateCertification", 300, 138, 46.0, 20.703333333333337, 4, 273, 11.0, 48.0, 69.89999999999998, 217.2300000000007, 1.6863595993209592, 0.2507801169771442, 1.1231418425164983], "isController": false}, {"data": ["SignIn", 300, 58, 19.333333333333332, 396.61333333333323, 174, 1518, 324.0, 645.9000000000008, 940.75, 1247.7800000000002, 1.669885835471715, 0.8023279600118005, 0.5365160545607366], "isController": false}, {"data": ["GetLanguage", 900, 0, 0.0, 12.496666666666668, 3, 323, 6.0, 24.0, 40.94999999999993, 107.97000000000003, 4.966257042428389, 1.4117243068622636, 2.415230475712244], "isController": false}, {"data": ["DeleteLanguage", 300, 179, 59.666666666666664, 15.58666666666667, 4, 214, 8.0, 34.0, 57.89999999999998, 151.8800000000001, 1.686786278555886, 0.24849348900496476, 0.9126600953455943], "isController": false}, {"data": ["DeleteSkill", 300, 121, 40.333333333333336, 13.729999999999999, 2, 249, 6.0, 28.0, 40.799999999999955, 209.20000000000073, 1.6842294369620994, 0.3748178049718453, 1.0525611603358354], "isController": false}, {"data": ["SearchSkillsByCategories", 300, 0, 0.0, 179.04, 71, 886, 131.5, 328.30000000000024, 443.5499999999999, 711.9300000000001, 1.6728748912631322, 8.527741144915575, 1.1615371559453973], "isController": false}, {"data": ["AddEducation", 300, 121, 40.333333333333336, 13.76000000000001, 3, 367, 7.0, 29.0, 46.0, 119.58000000000038, 1.6864543982730709, 0.3515422976816873, 1.1034418426200756], "isController": false}, {"data": ["ManageListingsDelete", 300, 0, 0.0, 25.053333333333335, 7, 394, 13.0, 48.900000000000034, 85.94999999999999, 171.82000000000016, 1.6742472863241902, 0.32700142311019337, 0.9057939420152357], "isController": false}, {"data": ["Transaction Controller", 0, 0, NaN, NaN, 9223372036854775807, -9223372036854775808, NaN, NaN, NaN, NaN, 0.0, 0.0, 0.0], "isController": true}, {"data": ["ShareSkillAddNew", 300, 0, 0.0, 36.78666666666666, 11, 320, 20.0, 77.80000000000007, 124.94999999999999, 241.84000000000015, 1.6778429650840878, 0.3670281486121443, 2.56100444768206], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 560 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 949 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 567 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 690 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 519 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 588 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 503 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 813 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 941 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,092 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 530 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 648 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 562 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 526 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 908 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 864 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,004 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,248 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 742 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 620 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 954 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 709 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,518 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["500/Internal Server Error", 540, 30.892448512585812, 7.5], "isController": false}, {"data": ["The operation lasted too long: It took 1,226 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 616 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 613 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 744 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 574 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 755 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,016 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 689 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 946 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,176 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 543 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 516 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, 0.11441647597254005, 0.027777777777777776], "isController": false}, {"data": ["The operation lasted too long: It took 548 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 977 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 776 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 511 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 532 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 586 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 590 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 717 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 955 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 746 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 916 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 580 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 627 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, 0.11441647597254005, 0.027777777777777776], "isController": false}, {"data": ["The operation lasted too long: It took 599 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,102 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 936 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 531 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, 0.11441647597254005, 0.027777777777777776], "isController": false}, {"data": ["The operation lasted too long: It took 557 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1150, 65.78947368421052, 15.972222222222221], "isController": false}, {"data": ["The operation lasted too long: It took 544 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}, {"data": ["The operation lasted too long: It took 1,395 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, 0.057208237986270026, 0.013888888888888888], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 7200, 1748, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 1150, "500/Internal Server Error", 540, "The operation lasted too long: It took 516 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, "The operation lasted too long: It took 627 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, "The operation lasted too long: It took 531 milliseconds, but should not have lasted longer than 500 milliseconds.", 2], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["DeleteEducation", 300, 121, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 121, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateSkill", 300, 140, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 140, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateEducation", 300, 133, "500/Internal Server Error", 121, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 12, "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteCertification", 300, 120, "500/Internal Server Error", 120, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["AddCertification", 300, 120, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 120, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddLanguage", 300, 179, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 179, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["AddSkill", 300, 121, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 121, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["UpdateLanguage", 300, 197, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 197, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["UpdateCertification", 300, 138, "500/Internal Server Error", 120, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 18, "", "", "", "", "", ""], "isController": false}, {"data": ["SignIn", 300, 58, "The operation lasted too long: It took 516 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, "The operation lasted too long: It took 627 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, "The operation lasted too long: It took 531 milliseconds, but should not have lasted longer than 500 milliseconds.", 2, "The operation lasted too long: It took 560 milliseconds, but should not have lasted longer than 500 milliseconds.", 1, "The operation lasted too long: It took 949 milliseconds, but should not have lasted longer than 500 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": ["DeleteLanguage", 300, 179, "500/Internal Server Error", 179, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["DeleteSkill", 300, 121, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 121, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["AddEducation", 300, 121, "Value in json path '$.success ' expected to match regexp 'true', but it did not match: 'false'", 121, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
